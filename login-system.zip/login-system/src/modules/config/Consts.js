export const loginPath = window.location.href.replace('sistema/index.html', 'index.html');
